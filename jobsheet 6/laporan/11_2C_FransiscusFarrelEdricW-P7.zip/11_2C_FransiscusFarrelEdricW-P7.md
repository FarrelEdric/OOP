﻿NAMA : Fransiscus Farrel Edric W![](Aspose.Words.f8e5f110-4967-47d7-82ec-fb2c9a65ff03.001.png)

NIM : 2241720032 

KELAS  : 2C 

` `P7 

Percobaan 1 Class A 

![](Aspose.Words.f8e5f110-4967-47d7-82ec-fb2c9a65ff03.002.png)

Class B 

![](Aspose.Words.f8e5f110-4967-47d7-82ec-fb2c9a65ff03.003.png)

Class percobaan 1 

![](Aspose.Words.f8e5f110-4967-47d7-82ec-fb2c9a65ff03.004.png)

Hasil run 

![](Aspose.Words.f8e5f110-4967-47d7-82ec-fb2c9a65ff03.005.jpeg)

**A. PERTANYAAN** 

1. Pada percobaan 1 diatas program yang dijalankan terjadi error, kemudian perbaiki sehingga program tersebut bisa dijalankan dan tidak error!

Di tambahkan konstruktor seper ti di bawah yang hasilnya

- Pada class B 
- ![](Aspose.Words.f8e5f110-4967-47d7-82ec-fb2c9a65ff03.006.png)
- Pada class percobaan 1 
- ![](Aspose.Words.f8e5f110-4967-47d7-82ec-fb2c9a65ff03.007.png)
- Hasil run 
- ![](Aspose.Words.f8e5f110-4967-47d7-82ec-fb2c9a65ff03.008.png)
2. Jelaskan apa penyebab program pada percobaan 1 ketika dijalankan terdapat error!
- Jadi error di sebabkan pada class B tidak terbaca pada get nilai x dan y maka kita tambahkan

Percobaa 2 class A 

![](Aspose.Words.f8e5f110-4967-47d7-82ec-fb2c9a65ff03.009.png)

class B 

![](Aspose.Words.f8e5f110-4967-47d7-82ec-fb2c9a65ff03.010.png)

Run 

![](Aspose.Words.f8e5f110-4967-47d7-82ec-fb2c9a65ff03.011.jpeg)

1. Pada percobaan 2 diatas program yang dijalankan terjadi error, kemudian perbaiki sehingga program tersebut bisa dijalankan dan tidak error!
- Karena harus menambahkan extends dan seter getter 
2. Jelaskan apa penyebab program pada percobaan 2 ketika dijalankan terdapat error!
- Karena tidak ada setter getternya 

PERCOBAAN 3 

Class Bangun 

![](Aspose.Words.f8e5f110-4967-47d7-82ec-fb2c9a65ff03.012.png)

Class tabung 

![](Aspose.Words.f8e5f110-4967-47d7-82ec-fb2c9a65ff03.013.jpeg)

Percoabaan 3 

![](Aspose.Words.f8e5f110-4967-47d7-82ec-fb2c9a65ff03.014.png)

Run 

![](Aspose.Words.f8e5f110-4967-47d7-82ec-fb2c9a65ff03.015.png)

1. Jelaskan fungsi “super” pada potongan program berikut di class Tabung!

![](Aspose.Words.f8e5f110-4967-47d7-82ec-fb2c9a65ff03.016.png)

- Untuk classs parent 
2. Jelaskan fungsi “super” dan “this” pada potongan program berikut di class 

Tabung!

![](Aspose.Words.f8e5f110-4967-47d7-82ec-fb2c9a65ff03.017.png)

- Untuk  menampilkan class perent 
3. Jelaskan mengapa pada class Tabung tidak dideklarasikan atribut “phi” dan “r” tetapi class tersebut dapat mengakses atribut tersebut! 
- atribut phi dan r sebenarnya dideklarasikan di dalam superclass (kelas induk) yang disebut Bangun. Oleh karena itu, kelas Tabung dapat mengakses atribut ini karena kelas anak (subclass) dapat mewarisi atribut dan metode dari kelas induk.

Percobaan 4 Class A 

![](Aspose.Words.f8e5f110-4967-47d7-82ec-fb2c9a65ff03.018.png)

Class B 

![](Aspose.Words.f8e5f110-4967-47d7-82ec-fb2c9a65ff03.019.png)

Class  C 

![](Aspose.Words.f8e5f110-4967-47d7-82ec-fb2c9a65ff03.020.png)

Percobaan 

![](Aspose.Words.f8e5f110-4967-47d7-82ec-fb2c9a65ff03.021.png)

Run 

![](Aspose.Words.f8e5f110-4967-47d7-82ec-fb2c9a65ff03.022.png)

1. Pada percobaan 4 sebutkan mana class yang termasuk superclass dan subclass, kemudian jelaskan alasannya!
- Superclass (B,C)
- Sub  class  (A)
2. Ubahlah isi konstruktor default ClassC seperti berikut:
- ![](Aspose.Words.f8e5f110-4967-47d7-82ec-fb2c9a65ff03.023.png)
3. Jelaskan bagaimana urutan proses jalannya konstruktor saat objek test dibuat! 

![](Aspose.Words.f8e5f110-4967-47d7-82ec-fb2c9a65ff03.024.jpeg)

4. Apakah fungsi super() pada potongan program dibawah ini di ClassC!
- Untuk mengidentifikasi class perent 

Tugas 

![](Aspose.Words.f8e5f110-4967-47d7-82ec-fb2c9a65ff03.025.png)
